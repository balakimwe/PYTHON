

class User:

    def __init__(self, first_name, last_name, email, account1, account2):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.checking = account1        
        self.saving = account2
    
    # other methods
    
    def make_deposit(self, amount, account):
        # your code here
        if account == "checking":
            self.checking.deposite(amount)
            print(f"Checking Balace: {self.checking.balance}")  
        elif account == "saving":
            self.saving.deposite(amount)
            print(f"Saving Balace: {self.saving.balance}") 
        return self 


    def make_withdraw(self, amount, account):
        if account == "checking":
            self.checking.withdraw(amount)
            print(f"withdraw ${amount} dollars from Checking Balance {amount}")
        elif account == "saving":
            self.saving.withdraw(amount)
            print(f"withdraw ${amount} dollars from Saving Balance {amount}")
        return self

    
    def display_user_balance(self):
        print(f"User:{self.first_name} {self.last_name} Checking: ${self.checking.balance}")
        print(f"User:{self.first_name} {self.last_name} Saving: ${self.saving.balance}")
        return self


