from user import User
from bank_account import BankAccount


user1 = User("Rose", "Nark", "rose@gmail.com", BankAccount(0.02, 0), BankAccount(0.3, 0))
user2 = User("Jeff", "Rock", "jeff@gmail.com", BankAccount(0.2, 0), BankAccount(0.3, 0))

user1.checking.display_account_info()
user1.saving.display_account_info()

user1.make_deposit(2000, "checking")
user1.make_deposit(4000, "saving")
user1.make_deposit(2000, "checking")
user1.make_withdraw(1000, "checking")
user1.display_user_balance()
