class BankAccount:

    accounts = []

    def __init__(self, int_rate, balance):
        self.int_rate = int_rate
        self.balance = balance
        BankAccount.accounts.append(self)


    def deposite(self, amount):
        self.balance += amount
        return self


    def withdraw(self, amount):
        if self.balance > amount:
            self.balance -= amount
            print(f"withdraw ${amount}. Available balance & {self.balance}")
        else:
            print("inssuficient funds: charge $5 fee")
            self.balance -= 5
        return self


    def yield_interest(self):
        # your code here
        if self.balance > 0:
            self.balance += (self.balance * self.int_rate)
            print(f"Balance After Yield Interest: {self.balance}")
        return self


    def display_account_info(self):
        print(self.balance)
        return self


    @classmethod
    def display_all_account(cls):
        for account in cls.accounts:
            print(f"account balance: {account.balance} account interest rate: {account.int_rate}")

